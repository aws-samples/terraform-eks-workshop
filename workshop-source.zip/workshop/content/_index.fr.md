+++
title = "Modèle d'atelier AWS"
chapter = true
weight = 1
+++
Ce modèle est le modèle par défaut pour la création de contenu d'atelier pour AWS Solutions Architecture. Il fonctionne sur Hugo, est piloté par Markdown et fournit une expérience interactive aux participants aux ateliers. Les pages de ce modèle fournissent des exemples permettant d’écrire votre propre contenu à l’aide des composants disponibles.

{{% button href="https://issues.amazon.com/issues/create?template=f084dc94-e920-4d98-80f7-252d5cc7ce00" icon="fas fa-bug" %}}Signaler un problème{{% /button %}}
{{% button href="mailto:aws-sa-customer-engagements@amazon.com" icon="fas fa-envelope" %}}Contact Event Outfitters{{% /button %}}
{{% button href="https://w.amazon.com/bin/view/AWS/Teams/SA/Customer_Engagements/" icon="fas fa-graduation-cap" %}}Apprendre encore plus{{% /button %}}