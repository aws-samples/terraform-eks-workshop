+++
title = "Requirements"
weight = 11
+++
This template is mostly "plug and play", but you will need to download the latest version of [Hugo binary (> 0.25)](https://gohugo.io/getting-started/installing/) for your OS (Windows, Linux, Mac) to develop your content locally.

If you haven't already, make sure you have an open Tech Content SIM ticket tracking the workshop you are developing. Don't know what the Tech Content Prioritization process is? Start [here](https://w.amazon.com/bin/view/AWS_Technical_Content/aws-tech-content-sim-dashboard/).