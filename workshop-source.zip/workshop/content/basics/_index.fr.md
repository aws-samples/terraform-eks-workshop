+++
title = "Les bases"
chapter = true
weight = 10
pre = "<b>1. </b>"
+++

Découvrez en quoi consiste ce modèle et quels sont ses concepts de base.